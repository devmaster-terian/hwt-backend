# ext-theme-crisp-4cf01f09-de9a-457c-8325-6be5c5701ad5/overrides

This folder contains overrides which will automatically be required by package users.
