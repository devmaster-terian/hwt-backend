# ext-theme-crisp-4cf01f09-de9a-457c-8325-6be5c5701ad5/sass/var

This folder contains variable declaration files named by their component class.
