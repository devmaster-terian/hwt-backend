# ext-theme-crisp-4cf01f09-de9a-457c-8325-6be5c5701ad5/sass/src

This folder contains SASS sources that mimic the component-class hierarchy. These files
are gathered in to a build of the CSS based on classes that are used by the build.
