# ext-theme-crisp-4cf01f09-de9a-457c-8325-6be5c5701ad5/sass/etc

This folder contains miscellaneous SASS files. Unlike `"ext-theme-crisp-4cf01f09-de9a-457c-8325-6be5c5701ad5/sass/etc"`, these files
need to be used explicitly.
