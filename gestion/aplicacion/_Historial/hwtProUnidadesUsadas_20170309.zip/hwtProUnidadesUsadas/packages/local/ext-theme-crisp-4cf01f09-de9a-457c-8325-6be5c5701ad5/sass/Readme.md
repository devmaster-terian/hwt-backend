# ext-theme-crisp-4cf01f09-de9a-457c-8325-6be5c5701ad5/sass

This folder contains SASS files of various kinds, organized in sub-folders:

    ext-theme-crisp-4cf01f09-de9a-457c-8325-6be5c5701ad5/sass/etc
    ext-theme-crisp-4cf01f09-de9a-457c-8325-6be5c5701ad5/sass/src
    ext-theme-crisp-4cf01f09-de9a-457c-8325-6be5c5701ad5/sass/var
